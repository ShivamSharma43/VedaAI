export function Loader() {
  return (
    <div className="flex justify-center items-center py-10">
      <div className="w-8 h-8 border-2 border-brand-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );
}